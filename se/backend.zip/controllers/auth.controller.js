import User    from '../models/User.model.js';
import Student from '../models/Student.model.js';
import Teacher from '../models/Teacher.model.js';
import jwt     from 'jsonwebtoken';
import { isValidIndianPhone, normalizePhone } from '../utils/phone.js';

const generateToken = (id, role) =>
  jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || '7d' });

const toSafeUser = user => {
  const u = typeof user?.toObject === 'function' ? user.toObject() : { ...user };
  delete u.password;
  return u;
};

const userPopulate = [
  { path: 'studentRef' },
  {
    path: 'teacherRef',
    populate: [
      { path: 'eligibleSubjects', select: 'name code color type' },
      { path: 'classTeacherOf', select: 'grade section displayName groupName' },
    ],
  },
];

// Ensure student user exists (auto-create on first login attempt)
const ensureStudentUser = async phone => {
  const student = await Student.findOne({ phone });
  if (!student) return null;
  let user = await User.findOne({ phone }).populate(userPopulate);
  if (user) return user;
  user = await User.create({
    name:         `${student.firstName} ${student.lastName}`.trim(),
    phone:        student.phone,
    email:        student.email || undefined,
    password:     student.admissionNo || student.phone,
    role:         'student',
    studentRef:   student._id,
    isFirstLogin: true,
  });
  if (!student.userRef) { student.userRef = user._id; await student.save(); }
  return User.findById(user._id).populate(userPopulate);
};

// ── POST /api/auth/login ─────────────────────────────────────────────────────
export const login = async (req, res) => {
  try {
    const { identifier, password } = req.body;
    const loginVal = (identifier || '').trim();
    if (!loginVal || !password)
      return res.status(400).json({ success: false, message: 'Identifier and password are required.' });

    const normPhone = normalizePhone(loginVal);
    const queries   = [];
    if (isValidIndianPhone(normPhone)) queries.push({ phone: normPhone });
    if (loginVal.includes('@'))         queries.push({ email: loginVal.toLowerCase() });
    if (!queries.length)                queries.push({ email: loginVal.toLowerCase() });

    let user = await User.findOne({ $or: queries }).populate(userPopulate);

    // Auto-create student user if not found
    if (!user && isValidIndianPhone(normPhone))
      user = await ensureStudentUser(normPhone);

    if (!user) return res.status(401).json({ success: false, message: 'No account found with this identifier.' });
    if (!user.isActive) return res.status(401).json({ success: false, message: 'Account is inactive. Contact admin.' });

    const match = await user.matchPassword(password);
    if (!match) return res.status(401).json({ success: false, message: 'Incorrect password.' });

    // Portal-Role Validation
    const { portal } = req.body;
    if (portal === 'student' && user.role !== 'student') {
      return res.status(403).json({ success: false, message: 'Access Denied: Please use the Student Portal to login.' });
    }
    if (portal === 'parent' && user.role !== 'parent') {
      return res.status(403).json({ success: false, message: 'Access Denied: Please use the Parent Portal to login.' });
    }
    if (portal === 'admin' && (user.role === 'student' || user.role === 'parent')) {
      return res.status(403).json({ success: false, message: 'Access Denied: You do not have permission to access the Staff Portal.' });
    }

    res.json({
      success: true,
      token:   generateToken(user._id, user.role),
      user:    toSafeUser(user),
      isFirstLogin: user.isFirstLogin,
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── GET /api/auth/me ─────────────────────────────────────────────────────────
export const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password').populate(userPopulate);
    res.json({ success: true, user: toSafeUser(user) });
  } catch (err) {
    console.error('Get current user error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── PUT /api/auth/change-password ────────────────────────────────────────────
export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!newPassword || newPassword.length < 6)
      return res.status(400).json({ success: false, message: 'New password must be at least 6 characters.' });

    const user = await User.findById(req.user._id);

    if (!user.isFirstLogin) {
      if (!currentPassword)
        return res.status(400).json({ success: false, message: 'Current password is required.' });
      const match = await user.matchPassword(currentPassword);
      if (!match)
        return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
    }

    user.password     = newPassword;
    user.isFirstLogin = false;
    await user.save();

    res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err) {
    console.error('Change password error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── PUT /api/auth/profile ─────────────────────────────────────────────────────
export const updateProfile = async (req, res) => {
  try {
    const { name, email } = req.body;
    const user = await User.findById(req.user._id);
    if (name)  user.name  = name;
    if (email) user.email = email.toLowerCase();
    await user.save();
    res.json({ success: true, user: toSafeUser(user) });
  } catch (err) {
    console.error('Update profile error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

export default { login, getMe, changePassword, updateProfile };
