import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  FiUsers, FiUser, FiGrid, FiDollarSign, FiAlertCircle, 
  FiCalendar, FiClock, FiBook, FiLayout, FiTarget, 
  FiClipboard, FiFileText, FiBarChart2, FiBriefcase, FiZap
} from 'react-icons/fi';
import api from '../../api/axios.js';
import { StatCard, PageLoader, PageHeader } from '../../components/common/index.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import useAcademicYear from '../../hooks/useAcademicYear.js';
import { ACCESS, canAccessRole, ROLES } from '../../utils/roleAccess.js';

export default function DashboardPage() {
  const { user } = useAuth();
  const academicYear = useAcademicYear();
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard', { params: { academicYear } })
      .then(r => setData(r.data.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [academicYear]);

  if (loading) return <PageLoader />;

  const isTeacherView = data?.isTeacher;

  const stats = isTeacherView ? [
    { icon: FiUsers,       label: "Class Students",   value: data?.studentsCount,     sub: "Inside your classroom",    color: "text-blue-600", border: "border-blue-200" },
    { icon: FiClock,       label: "Today's Periods",  value: data?.todayPeriods,      sub: "Teaching schedule",        color: "text-indigo-600", border: "border-indigo-200" },
    { icon: FiBook,        label: "Pending Homework", value: data?.pendingHomework,   sub: "Active assignments",       color: "text-amber-600", border: "border-amber-200" },
    { icon: FiCalendar,    label: "Leave Requests",   value: data?.pendingLeaves,     sub: "Student applications",     color: "text-emerald-600", border: "border-emerald-200" },
  ] : [
    { icon: FiUsers,       label: "Total Students",   value: data?.students?.total,   sub: "Active and enrolled",      color: "text-blue-600", border: "border-blue-200" },
    { icon: FiUser,        label: "Teachers",         value: data?.teachers,          sub: "Faculty members",           color: "text-indigo-600", border: "border-indigo-200" },
    { icon: FiGrid,        label: "Classes",          value: data?.classes,           sub: "Active sections",         color: "text-violet-600", border: "border-violet-200" },
    { icon: FiBriefcase,   label: "Staff",            value: data?.staffCount || '—', sub: "Non-teaching",           color: "text-emerald-600", border: "border-emerald-200" },
  ];

  const MODULES = [
    { to: '/admin/students/new', label: 'New Admission', icon: FiZap, accessKey: 'students_manage', color: 'text-orange-600' },
    { to: '/admin/students', label: 'Student Directory', icon: FiUsers, accessKey: 'students_view', color: 'text-blue-600' },
    { to: '/admin/teachers', label: 'Manage Staff', icon: FiUser, accessKey: 'staff', color: 'text-indigo-600' },
    { to: '/admin/class-subjects', label: 'Allocations', icon: FiTarget, accessKey: 'subject_allocation', color: 'text-pink-600' },
    { to: '/admin/attendance', label: 'Attendance', icon: FiCalendar, accessKey: 'attendance', color: 'text-emerald-600' },
    { to: '/admin/timetable', label: 'Master Schedule', icon: FiClock, accessKey: 'timetable_manage', color: 'text-blue-600' },
    { to: '/admin/timetable/teacher', label: 'My Schedule', icon: FiClock, accessKey: 'timetable_view', color: 'text-indigo-600', roles: [ROLES.TEACHER, ROLES.CLASS_TEACHER] },
    { to: '/admin/exams', label: 'Exam Marks', icon: FiClipboard, accessKey: 'exams', color: 'text-amber-600' },
    { to: '/admin/report-cards', label: 'Report Cards', icon: FiFileText, accessKey: 'report_cards', color: 'text-violet-600' },
    { to: '/admin/homework', label: 'Homework', icon: FiBook, accessKey: 'homework', color: 'text-slate-600' },
    { to: '/admin/fees/list', label: 'Fee Payments', icon: FiDollarSign, accessKey: 'fees_list', color: 'text-emerald-600' },
    { to: '/admin/settings', label: 'Settings', icon: FiLayout, accessKey: 'settings', color: 'text-slate-600' },
  ];

  const allowedModules = MODULES.filter(m => {
    const hasRoleAccess = canAccessRole(user?.role, m.accessKey);
    if (m.roles) return hasRoleAccess && m.roles.includes(user.role);
    return hasRoleAccess;
  });

  return (
    <div className="space-y-12">
      <PageHeader title={`Welcome back, ${user?.name}`} subtitle="Jump into your daily modules and tasks" />

      {/* Role-Based Module Access - Now the Primary View */}
      <div>
        <div className="mb-6 flex items-center justify-between">
          <h3 className="text-xl font-black text-slate-900 tracking-tight lowercase first-letter:uppercase">Essential Modules</h3>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full italic">Administered Dashboard</span>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
          {allowedModules.map(item => (
            <Link key={item.to} to={item.to}
              className="group relative flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition-all hover:border-primary-500 hover:shadow-xl hover:shadow-primary-100 hover:-translate-y-1">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-50 transition-colors group-hover:bg-primary-50">
                <item.icon className={`text-2xl ${item.color} transition-transform group-hover:scale-110`} />
              </div>
              <span className="text-center text-[13px] font-black text-slate-800 uppercase tracking-tight leading-none">{item.label}</span>
              <div className="absolute top-2 right-2 opacity-0 transition-opacity group-hover:opacity-100">
                 <div className="h-1.5 w-1.5 rounded-full bg-primary-500 animate-ping" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

