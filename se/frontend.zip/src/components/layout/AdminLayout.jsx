import React, { useState, useMemo, useEffect } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import {
  FiBarChart2, FiUsers, FiUser, FiBook, FiCalendar, FiClock, FiGrid,
  FiFileText, FiDollarSign, FiTrendingDown, FiBell,
  FiLogOut, FiMenu, FiX, FiChevronRight, FiShield, FiEdit3,
  FiTarget, FiClipboard, FiAlertCircle, FiSettings, FiLayout,
} from 'react-icons/fi';
import { ACCESS, ROLES } from '../../utils/roleAccess.js';
import useAcademicYear from '../../hooks/useAcademicYear.js';

const NAV = [
  { type: 'link', key: 'dash', label: 'Dashboard', icon: FiLayout, to: '/admin', accessKey: 'dashboard' },
  {
    type: 'group', key: 'students', label: 'Students', icon: FiUser,
    children: [
      { to: '/admin/students', label: 'Student Directory', icon: FiUsers, accessKey: 'students_view' },
      { to: '/admin/students/new', label: 'New Admission', icon: FiEdit3, accessKey: 'students_manage' },
      { to: '/admin/attendance', label: 'Attendance', icon: FiClock, accessKey: 'attendance' },
    ],
  },
  {
    type: 'group', key: 'academic', label: 'Academic', icon: FiGrid,
    children: [
      { to: '/admin/classes', label: 'Classes', icon: FiGrid, accessKey: 'classes' },
      { to: '/admin/subjects', label: 'Subjects', icon: FiBook, accessKey: 'subjects' },
      { to: '/admin/teachers', label: 'Teachers', icon: FiUsers, accessKey: 'teachers' },
      { 
        to: '/admin/class-subjects', 
        label: 'Allocated Subjects', 
        icon: FiTarget, 
        accessKey: 'subject_allocation',
        allowedRoles: [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.PRINCIPAL]
      },
    ],
  },
  {
    type: 'group', key: 'timetable', label: 'Timetable', icon: FiClock,
    children: [
      { to: '/admin/timetable', label: 'Master View', icon: FiCalendar, accessKey: 'timetable_manage' },
      { to: '/admin/timetable/teacher', label: 'My Schedule', icon: FiClock, accessKey: 'timetable_view', allowedRoles: [ROLES.TEACHER, ROLES.CLASS_TEACHER] },
      { to: '/admin/timetable/periods', label: 'Periods', icon: FiGrid, accessKey: 'timetable_manage' },
      { to: '/admin/timetable/workload', label: 'My Workload', icon: FiBarChart2, accessKey: 'timetable_view', allowedRoles: [ROLES.TEACHER, ROLES.CLASS_TEACHER] },
      { to: '/admin/substitutions', label: 'Substitutions', icon: FiTrendingDown, accessKey: 'substitutions' },
    ],
  },
  {
    type: 'group', key: 'exams', label: 'Assessments', icon: FiClipboard,
    children: [
      { to: '/admin/exams', label: 'Exam Marks', icon: FiClipboard, accessKey: 'exams' },
      { to: '/admin/report-cards', label: 'Report Cards', icon: FiFileText, accessKey: 'report_cards' },
      { to: '/admin/homework', label: 'Homework', icon: FiBook, accessKey: 'homework' },
    ],
  },
  {
    type: 'group', key: 'accounts', label: 'Finance', icon: FiDollarSign,
    children: [
      { to: '/admin/fees/structures', label: 'Fee Structures', icon: FiGrid, accessKey: 'fees_structure' },
      { to: '/admin/fees/assign', label: 'Assign Fees', icon: FiEdit3, accessKey: 'fees_assign' },
      { to: '/admin/fees/list', label: 'Fees Collection', icon: FiDollarSign, accessKey: 'fees_list' },
      { to: '/admin/expenses', label: 'Expenses', icon: FiTrendingDown, accessKey: 'expenses' },
    ],
  },
  {
    type: 'group', key: 'ops', label: 'Operations', icon: FiSettings,
    children: [
      { to: '/admin/library', label: 'Library', icon: FiBook, accessKey: 'library' },
      { to: '/admin/circulars', label: 'Circulars', icon: FiBell, accessKey: 'circulars' },
      { to: '/admin/leave', label: 'Leave Requests', icon: FiCalendar, accessKey: 'leave' },
    ],
  },
  {
    type: 'group', key: 'admin', label: 'Administration', icon: FiShield,
    children: [
      { to: '/admin/staff', label: 'Staff Management', icon: FiShield, accessKey: 'staff' },
      { to: '/admin/settings', label: 'Settings', icon: FiSettings, accessKey: 'settings' },
      { to: '/admin/reports', label: 'Reports', icon: FiBarChart2, accessKey: 'reports' },
    ],
  },
];

const ROLE_LABELS = {
  super_admin: 'Super Admin', admin: 'Admin', principal: 'Principal',
  teacher: 'Teacher', class_teacher: 'Class Teacher',
  accountant: 'Accountant', librarian: 'Librarian', admission_staff: 'Admission Staff',
};

function canAccess(userRole, item) {
  if (item.accessKey) {
    return (ACCESS[item.accessKey] || []).includes(userRole);
  }
  return !item.allowedRoles || item.allowedRoles.includes(userRole);
}

function matchPath(pathname, to) {
  if (to === '/admin') return pathname === '/admin';
  return pathname === to || pathname.startsWith(to + '/');
}

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const academicYear = useAcademicYear();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState(null);

  // Auto-open active group on location change
  useEffect(() => {
    for (const e of NAV) {
      if (e.type === 'group') {
        const hasActiveChild = e.children?.some(c => matchPath(location.pathname, c.to));
        if (hasActiveChild) {
          setOpenGroup(e.key);
          break;
        }
      }
    }
  }, [location.pathname]);

  const pageTitle = useMemo(() => {
    for (const e of NAV) {
      if (!canAccess(user?.role, e)) continue;
      if (e.type === 'link' && matchPath(location.pathname, e.to)) return { title: e.label, sub: 'Overview and insights' };
      if (e.type === 'group') {
        const child = e.children?.find(c => canAccess(user?.role, c) && matchPath(location.pathname, c.to));
        if (child) return { title: child.label, sub: `Manage your ${child.label.toLowerCase()} system` };
      }
    }
    return { title: 'Administration', sub: 'Manage your school ecosystem' };
  }, [location.pathname, user?.role]);

  const handleLogout = () => { logout(); navigate('/login'); };

  const toggleGroup = key => {
    setOpenGroup(current => (current === key ? null : key));
  };

  const renderLink = (item, nested = false) => (
    <NavLink
      key={item.to} to={item.to} end={item.to === '/admin'}
      onClick={() => setMobileOpen(false)}
      className={({ isActive }) => [
        nested ? 'portal-nav-sublink' : 'portal-nav-link',
        isActive ? (nested ? 'portal-nav-sublink-active' : 'portal-nav-link-active') : '',
      ].join(' ')}
    >
      <item.icon className="shrink-0 text-lg" />
      <span className="truncate">{item.label}</span>
    </NavLink>
  );

  const renderSidebar = () => (
    <div className="portal-sidebar">
      <div className="portal-sidebar-brand mb-2">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 font-bold text-white shadow-lg backdrop-blur-sm ring-1 ring-white/20">
            <FiGrid />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-white tracking-tight leading-none text-blue-50">School ERP</p>
            <p className="portal-sidebar-copy mt-1 uppercase font-semibold tracking-wider text-blue-200/60">Portal System</p>
          </div>
        </div>
      </div>

      <nav className="portal-sidebar-scroll flex-1 overflow-y-auto py-2">
        <div className="space-y-1">
          {NAV.map(entry => {
            if (!canAccess(user?.role, entry)) return null;
            if (entry.type === 'link') return renderLink(entry);
            const visibleChildren = entry.children?.filter(child => canAccess(user?.role, child)) || [];
            if (visibleChildren.length === 0) return null;
            
            const isOpen = openGroup === entry.key;
            const isChildActive = visibleChildren.some(c => matchPath(location.pathname, c.to));
            
            return (
              <div key={entry.key} className="space-y-1">
                <button
                  type="button"
                  onClick={() => toggleGroup(entry.key)}
                  className={`portal-nav-group-btn w-[calc(100%-24px)] ${isOpen || isChildActive ? 'bg-white/10' : ''}`}
                >
                  <div className="flex items-center gap-3">
                    <entry.icon className={`text-lg transition-colors ${isOpen || isChildActive ? 'text-white' : 'text-blue-200'}`} />
                    <span className="truncate">{entry.label}</span>
                  </div>
                  <FiChevronRight className={`transition-transform duration-200 ${isOpen ? 'rotate-90' : ''} text-blue-300`} />
                </button>
                
                {isOpen && (
                  <div className="space-y-1 overflow-hidden transition-all duration-300">
                    {visibleChildren.map(c => renderLink(c, true))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </nav>

      <div className="mt-auto px-4 py-4 space-y-4 bg-blue-900/20 divide-y divide-blue-700/30">
        <div className="pt-2">
          <p className="text-[10px] font-bold uppercase tracking-wider text-blue-300 mb-2">Academic Year</p>
          <div className="flex items-center justify-between rounded-lg border border-blue-600/30 bg-blue-800/40 px-3 py-2 text-sm font-semibold text-white">
            <span>{academicYear}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 px-1 pt-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/10 text-white font-bold text-sm ring-1 ring-white/20">
            {user?.name?.charAt(0) || 'S'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-white leading-none">{user?.name}</p>
            <p className="text-[11px] font-medium text-blue-300 mt-1 uppercase tracking-tight">{user?.role?.replace('_', ' ')}</p>
          </div>
          <button 
            type="button" 
            onClick={handleLogout} 
            className="flex h-8 w-8 items-center justify-center text-blue-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors border border-transparent hover:border-white/20"
          >
            <FiLogOut className="text-lg" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="app-shell flex h-screen overflow-hidden bg-slate-50">
      {/* Desktop sidebar */}
      <aside className="hidden h-screen w-72 shrink-0 lg:block">{renderSidebar()}</aside>

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="lg:hidden flex items-center border-b border-slate-200 bg-white px-4 py-3">
          <button onClick={() => setMobileOpen(true)} className="text-slate-500"><FiMenu className="text-2xl" /></button>
          <span className="ml-4 font-bold text-slate-900 text-lg">School ERP</span>
        </header>

        {mobileOpen && (
          <div className="fixed inset-0 z-40 flex lg:hidden">
            <div className="fixed inset-0 bg-slate-900/60 transition-opacity" onClick={() => setMobileOpen(false)} />
            <div className="relative flex w-full max-w-xs flex-1 flex-col bg-white">
              <button onClick={() => setMobileOpen(false)} className="absolute right-4 top-4 text-slate-500"><FiX className="text-2xl" /></button>
              {renderSidebar()}
            </div>
          </div>
        )}

        <main className="flex-1 overflow-y-auto px-6 py-10 lg:px-12">
          <div className="mx-auto max-w-6xl">
            <div className="mb-10">
              <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">{pageTitle.title}</h1>
              <p className="mt-2 text-slate-500 font-medium">{pageTitle.sub}</p>
            </div>
            
            <div className="float-in">
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

