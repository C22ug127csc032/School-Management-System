/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#2563eb', // Modern vibrant blue
          600: '#1d4ed8',
          700: '#1e40af',
          800: '#1e3a8a',
          900: '#1e3a5f',
        },
        sidebar: {
          light: '#ffffff',
          active: '#eff6ff',
          text: '#475569',
          'text-active': '#2563eb',
        },
        'app-bg': '#f8fafc',
        'card-bg': '#ffffff',
        accent: '#f1f5f9',
        border: '#e2e8f0',
        'text-main': '#0f172a',
        'text-muted': '#64748b',
      },
      borderRadius: {
        'xl': '12px',
        '2xl': '16px',
      },
      boxShadow: {
        'soft': '0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05)',
        'premium': '0 10px 15px -3px rgb(0 0 0 / 0.04), 0 4px 6px -4px rgb(0 0 0 / 0.04)',
      }
    },
  },
  plugins: [],
};

